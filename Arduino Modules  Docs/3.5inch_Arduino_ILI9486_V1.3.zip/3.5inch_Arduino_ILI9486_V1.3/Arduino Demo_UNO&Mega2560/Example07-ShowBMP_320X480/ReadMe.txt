ReadMe:
"ShowBMP"example need to read BMP files from SDcard.
so, firstly,you should format your SD-card into fat16 or fat32.
then copy the 01.bmp,02.bmp,03.bmp,04.bmp into your SD-card.

Attention:
This Example only support the Arduino UNO board,not support the Mega2560,Because they use different SPI bus.